import py_compile
py_compile.compile("test1.py")
py_compile.compile("test2.py")
py_compile.compile("test3.py")
py_compile.compile("db_func.py")
py_compile.compile("switch_handler.py")
#py_compile.compile("main.py")

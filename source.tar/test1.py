def show1():
	print "I am show1"

from db_func import database
from switch_handler import setup_pinout
import test1,test2,test3
import time

def main():
    #test1.show1()
    #test2.show2()
    #test3.show3()
    #con = database("192.168.0.202", "ahmed", "ahmed", "homedbRPI")
    module = setup_pinout()

    # module.get_status()

    # module.switch_handler()
    module.test_switch()


if __name__ == "__main__":
    main()

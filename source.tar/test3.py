def show3():
	print "I am show3"

from RPi import GPIO

import RPi.GPIO as GPIO
import time

# Pin Definitons:
pwmPin = 18 # Broadcom pin 18 (P1 pin 12)
ledPin = 16 # Broadcom pin 23 (P1 pin 16)
butPin = 17 # Broadcom pin 17 (P1 pin 11)


GPIO.setwarnings(False)
# Pin Setup:
GPIO.setmode(GPIO.BOARD) # Broadcom pin-numbering scheme
GPIO.setup(ledPin, GPIO.OUT) # LED pin set as output





# Initial state for LEDs:
GPIO.output(ledPin, GPIO.HIGH)
time.sleep(1)
GPIO.output(ledPin, GPIO.LOW)

print("Here we go! Press CTRL+C to exit")

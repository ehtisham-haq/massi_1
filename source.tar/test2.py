def show2():
	print "I am show2"
